--------------------------------------------------------------------
SOURCE-11-05-85
--------------------------------------------------------------------
This folder contains some files from a snapshot of Starflight source 
code printed out on November 5, 1985.  This was work in progress not 
the final version.

The shipping version was completed later and then revised after
first publication to add EGA graphics adapter support.

This is the most complete version currently available but not all
of is is published here yet. I'm still in the process of scanning
the printouts but plan to put it all online eventually with the
exception of a few copyrighted files.
--------------------------------------------------------------------
29Nov02 Tim Lee
10Mar03 Converted format of some these files to PDF.
