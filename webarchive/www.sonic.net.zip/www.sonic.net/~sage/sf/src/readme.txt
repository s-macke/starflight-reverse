README.TXT -- STARFLIGHT 1 SOURCE CODE LIBRARY
===================================================================
02Nov02 Tim Lee

The complete Starflight 1 source code is still being recovered from
floppy disks and printouts from that period.

The folders that start with "Disk-" contain files from floppy disks
used during the making of Starflight 1 but may not be the code that
ended up in the final version.

Most of the Starflight source code was held in the form of Forth
block files which is organized as 1024 byte blocks, 16 lines of
64 bytes per line.  

I've included text versions of these files in folders called 
"AsText".

The main routine that runs when Starflight starts up is called
"LET-THERE-BE-STARFLIGHT" and it can be found in file SBOOT.CMP 
(SBOOT.TXT).